import java.util.Date;

public abstract class Documento {
    protected int numero;
    protected Date fecha;

    public Documento(int numero) {
        this.numero = numero;
        this.fecha = new Date();
    }

    public abstract void mostrarResumen();
    public int getNumero() { return numero; }
}