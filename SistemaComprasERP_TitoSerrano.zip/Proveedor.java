import java.util.*;

public class Proveedor extends Persona {
    private String empresa;
    private List<Producto> productos;

    public Proveedor(String id, String nombre, String empresa) {
        super(id, nombre);
        this.empresa = empresa;
        this.productos = new ArrayList<>();
    }

    public void agregarProducto(Producto p) {
        productos.add(p);
    }

    public List<Producto> getProductos() { return productos; }
    public String getEmpresa() { return empresa; }
}