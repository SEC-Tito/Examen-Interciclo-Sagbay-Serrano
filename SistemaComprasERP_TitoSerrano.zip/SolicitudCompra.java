import java.util.*;

public class SolicitudCompra extends Documento implements Calculable {
    private String departamento;
    private List<ItemSolicitud> items;
    private EstadoSolicitud estado;

    public SolicitudCompra(int numero, String departamento) {
        super(numero);
        this.departamento = departamento;
        this.items = new ArrayList<>();
        this.estado = EstadoSolicitud.SOLICITADA;
    }

    public void agregarItem(ItemSolicitud item) {
        items.add(item);
    }

    public double calcularCostoTotal() {
        double total = 0;
        for (ItemSolicitud item : items) {
            total += item.subtotal();
        }
        return total;
    }

    public void aprobar() { estado = EstadoSolicitud.APROBADA; }
    public void rechazar() { estado = EstadoSolicitud.RECHAZADA; }

    public EstadoSolicitud getEstado() { return estado; }

    public void mostrarResumen() {
        System.out.println("Solicitud #: " + numero + ", Departamento: " + departamento);
        System.out.println("Estado: " + estado);
        System.out.println("Items:");
        for (ItemSolicitud item : items) {
            System.out.println("- " + item.getProducto().getNombre() + ", Cant: " + item.getCantidad());
        }
        System.out.println("Total: $" + calcularCostoTotal());
    }
}