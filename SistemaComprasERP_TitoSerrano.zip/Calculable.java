public interface Calculable {
    double calcularCostoTotal();
}