public class Producto implements Calculable {
    private String nombre;
    private double precioUnitario;
    private String unidadMedida;
    private Proveedor proveedor;

    public Producto(String nombre, double precioUnitario, String unidadMedida, Proveedor proveedor) {
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.unidadMedida = unidadMedida;
        this.proveedor = proveedor;
    }

    public double calcularCostoTotal() {
        return precioUnitario;
    }

    public String getNombre() { return nombre; }
    public double getPrecioUnitario() { return precioUnitario; }
    public Proveedor getProveedor() { return proveedor; }
}